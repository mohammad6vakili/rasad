const Colors = {
    royalBlue:"#001D53",
    secondary:"#dedede",
    aqua:"#00ECEC",
    danger:"#C41414",
}
export default Colors;
